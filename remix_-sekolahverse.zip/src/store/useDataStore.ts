import { create } from 'zustand';
import { mockData } from '../services/mockData';

export type Student = typeof mockData.students[0];
export type Teacher = typeof mockData.teachers[0];
export type Course = typeof mockData.courses[0];
export type Classroom = { id: string, name: string, wali: string, students: number };
export type Transaction = { id: string, date: string, description: string, type: string, amount: number, status: string };

interface DataState {
  students: Student[];
  teachers: Teacher[];
  courses: Course[];
  classes: Classroom[];
  transactions: Transaction[];
  
  addStudent: (student: Omit<Student, 'id'>) => void;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;

  addTeacher: (teacher: Omit<Teacher, 'id'>) => void;
  updateTeacher: (id: string, teacher: Partial<Teacher>) => void;
  deleteTeacher: (id: string) => void;

  addCourse: (course: Omit<Course, 'id'>) => void;
  updateCourse: (id: string, course: Partial<Course>) => void;
  deleteCourse: (id: string) => void;
  
  addClassroom: (classroom: Omit<Classroom, 'id'>) => void;
  updateClassroom: (id: string, classroom: Partial<Classroom>) => void;
  deleteClassroom: (id: string) => void;

  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
}

export const useDataStore = create<DataState>((set) => ({
  students: mockData.students,
  teachers: mockData.teachers,
  courses: mockData.courses,
  classes: [
    { id: '1', name: 'X IPA 1', wali: 'Bapak Hendra', students: 32 },
    { id: '2', name: 'X IPA 2', wali: 'Ibu Siti', students: 30 }
  ],
  transactions: [
    { id: 'TRX-001', date: '2024-03-15', description: 'Pembayaran SPP Budi Santoso (10 IPA 1)', type: 'income', amount: 500000, status: 'Success' },
    { id: 'TRX-002', date: '2024-03-15', description: 'Pembelian Alat Laboratorium', type: 'expense', amount: 2500000, status: 'Success' },
    { id: 'TRX-003', date: '2024-03-14', description: 'Pembayaran SPP Siti Aminah (10 IPS 2)', type: 'income', amount: 500000, status: 'Success' },
    { id: 'TRX-004', date: '2024-03-14', description: 'Honorarium Guru Honorer', type: 'expense', amount: 8000000, status: 'Pending' },
    { id: 'TRX-005', date: '2024-03-13', description: 'Dana BOS Cair', type: 'income', amount: 50000000, status: 'Success' },
  ],

  addStudent: (student) => set((state) => {
    const id = (Math.max(0, ...state.students.map(s => parseInt(s.id) || 0)) + 1).toString();
    return { students: [...state.students, { ...student, id }] };
  }),
  updateStudent: (id, updatedFields) => set((state) => ({
    students: state.students.map((s) => s.id === id ? { ...s, ...updatedFields } : s)
  })),
  deleteStudent: (id) => set((state) => ({
    students: state.students.filter((s) => s.id !== id)
  })),

  addTeacher: (teacher) => set((state) => {
    const id = `G-${String(Math.max(0, ...state.teachers.map(t => parseInt(t.id.split('-')[1]) || 0)) + 1).padStart(3, '0')}`;
    return { teachers: [...state.teachers, { ...teacher, id }] };
  }),
  updateTeacher: (id, updatedFields) => set((state) => ({
    teachers: state.teachers.map((t) => t.id === id ? { ...t, ...updatedFields } : t)
  })),
  deleteTeacher: (id) => set((state) => ({
    teachers: state.teachers.filter((t) => t.id !== id)
  })),

  addCourse: (course) => set((state) => {
    const id = `C-${String(Math.max(0, ...state.courses.map(c => parseInt(c.id.split('-')[1]) || 0)) + 1).padStart(3, '0')}`;
    return { courses: [...state.courses, { ...course, id }] };
  }),
  updateCourse: (id, updatedFields) => set((state) => ({
    courses: state.courses.map((c) => c.id === id ? { ...c, ...updatedFields } : c)
  })),
  deleteCourse: (id) => set((state) => ({
    courses: state.courses.filter((c) => c.id !== id)
  })),
  
  addClassroom: (classroom) => set((state) => {
    const id = (Math.max(0, ...state.classes.map(c => parseInt(c.id) || 0)) + 1).toString();
    return { classes: [...state.classes, { ...classroom, id }] };
  }),
  updateClassroom: (id, updatedFields) => set((state) => ({
    classes: state.classes.map((c) => c.id === id ? { ...c, ...updatedFields } : c)
  })),
  deleteClassroom: (id) => set((state) => ({
    classes: state.classes.filter((c) => c.id !== id)
  })),

  addTransaction: (transaction) => set((state) => {
    const id = `TRX-${String(Math.max(0, ...state.transactions.map(t => parseInt(t.id.split('-')[1]) || 0)) + 1).padStart(3, '0')}`;
    return { transactions: [...state.transactions, { ...transaction, id }] };
  }),
  updateTransaction: (id, updatedFields) => set((state) => ({
    transactions: state.transactions.map((t) => t.id === id ? { ...t, ...updatedFields } : t)
  })),
  deleteTransaction: (id) => set((state) => ({
    transactions: state.transactions.filter((t) => t.id !== id)
  })),
}));
