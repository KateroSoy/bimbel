import { useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { motion, AnimatePresence } from 'motion/react';
import { PlayCircle, FileText, CheckCircle2, ChevronLeft, ChevronRight, Award, MessageCircle, Download } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';

export default function LessonDetail() {
  const navigate = useNavigate();
  const { id } = useParams();
  
  const [isCompleted, setIsCompleted] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleComplete = () => {
    setIsCompleted(true);
    setShowConfetti(true);
    toast.success('Luar biasa! Materi telah diselesaikan.', {
      description: 'Progress belajar Anda telah diperbarui.'
    });
    
    // Hide confetti after 3s
    setTimeout(() => {
      setShowConfetti(false);
    }, 3000);
  };

  return (
    <DashboardLayout>
      {/* Simple full screen layout for lesson player to maximize focus */}
      <div className="max-w-[1400px] mx-auto h-[calc(100vh-8rem)] min-h-[600px] flex flex-col lg:flex-row gap-6">
        
        {/* Main Content Area (Left) */}
        <div className="flex-1 flex flex-col min-h-0 bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
          {/* Header */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-slate-50/50">
            <button 
              onClick={() => navigate('/siswa/course/2')}
              className="flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
              Kembali ke Course
            </button>
            <div className="text-xs font-bold px-3 py-1 bg-blue-100 text-blue-700 rounded-lg">
              Modul 2 • Pelajaran 2
            </div>
          </div>

          {/* Player Area */}
          <div className="flex-1 bg-slate-900 relative overflow-hidden flex items-center justify-center group group-video">
            <video 
              controls 
              className="w-full h-full object-contain"
              poster="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070&auto=format&fit=crop"
              src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            >
              Your browser does not support the video tag.
            </video>
          </div>

          {/* Lesson Details & Actions */}
          <div className="p-6 shrink-0 bg-white border-t border-slate-100">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
              <div>
                <h1 className="text-2xl font-display font-bold text-slate-900 mb-2">Listening Part B: Longer Conversations</h1>
                <p className="text-slate-500 text-sm leading-relaxed max-w-2xl">
                  Dalam sesi ini kita akan membahas strategi menghadapi Part B pada ujian TOEFL Listening. Fokus pada pencarian topik utama dan detail penting dari percakapan panjang.
                </p>
              </div>
              
              <div className="flex items-center gap-3 shrink-0">
                <AnimatePresence mode="wait">
                  {!isCompleted ? (
                    <motion.button
                      key="mark-complete"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      onClick={handleComplete}
                      className="px-6 py-3 bg-blue-600 text-white rounded-xl font-bold shadow-md shadow-blue-600/20 hover:bg-blue-700 transition-colors flex items-center gap-2"
                    >
                      Tandai Selesai
                    </motion.button>
                  ) : (
                    <motion.button
                      key="completed"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="px-6 py-3 bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl font-bold flex items-center gap-2 cursor-default"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      Selesai
                    </motion.button>
                  )}
                </AnimatePresence>
                
                {isCompleted && (
                  <motion.button
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    onClick={() => navigate('/siswa/quiz')} // Next is a quiz
                    className="px-6 py-3 bg-slate-900 text-white rounded-xl font-bold shadow-md hover:bg-slate-800 transition-colors flex items-center gap-2"
                  >
                    Selanjutnya
                    <ChevronRight className="w-5 h-5" />
                  </motion.button>
                )}
              </div>
            </div>

            {/* Additional Resources Tabs */}
            <div className="mt-8 pt-6 border-t border-slate-100 flex gap-6">
              <button className="flex items-center gap-2 text-sm font-bold text-blue-600 border-b-2 border-blue-600 pb-2">
                <FileText className="w-4 h-4" /> Catatan Materi
              </button>
              <button className="flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-slate-900 pb-2 transition-colors">
                <Download className="w-4 h-4" /> Unduh Lampiran
              </button>
              <button className="flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-slate-900 pb-2 transition-colors">
                <MessageCircle className="w-4 h-4" /> Diskusi (12)
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar Syllabus (Right) */}
        <div className="w-full lg:w-80 flex flex-col min-h-0 bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm shrink-0">
          <div className="p-5 border-b border-slate-100 bg-slate-50/50 shrink-0">
            <h3 className="font-bold text-slate-900">Daftar Pelajaran</h3>
            <div className="mt-2 w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-1000" 
                style={{ width: isCompleted ? '60%' : '55%' }}
              ></div>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-2 text-right">
              Progress: {isCompleted ? '60%' : '55%'}
            </p>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            
            {/* Module 1 */}
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">Modul 1</p>
              <div className="space-y-1">
                <div className="flex items-center gap-3 p-2 rounded-xl text-slate-500 cursor-default">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span className="text-sm font-medium line-clamp-1">Apa itu TOEFL?</span>
                </div>
                <div className="flex items-center gap-3 p-2 rounded-xl text-slate-500 cursor-default">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span className="text-sm font-medium line-clamp-1">Format Listening, Structure</span>
                </div>
              </div>
            </div>

            {/* Module 2 */}
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2 mt-4">Modul 2</p>
              <div className="space-y-1">
                <div className="flex items-center gap-3 p-2 rounded-xl text-slate-500 cursor-default">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span className="text-sm font-medium line-clamp-1">Listening Part A</span>
                </div>
                
                {/* Active Lesson */}
                <div className="flex items-center gap-3 p-2 rounded-xl bg-blue-50 text-blue-700 cursor-default border border-blue-100">
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  ) : (
                    <PlayCircle className="w-4 h-4 text-blue-600 shrink-0" />
                  )}
                  <span className="text-sm font-bold line-clamp-1">Listening Part B</span>
                </div>
                
                {/* Next Lesson */}
                <div className="flex items-center gap-3 p-2 rounded-xl text-slate-500 cursor-default opacity-75">
                  <Award className="w-4 h-4 text-slate-300 shrink-0" />
                  <span className="text-sm font-medium line-clamp-1">Latihan Listening 1</span>
                </div>
              </div>
            </div>

             {/* Module 3 */}
             <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2 mt-4">Modul 3</p>
              <div className="space-y-1 opacity-50">
                <div className="flex items-center gap-3 p-2 rounded-xl text-slate-500 cursor-default">
                  <PlayCircle className="w-4 h-4 text-slate-300 shrink-0" />
                  <span className="text-sm font-medium line-clamp-1">Grammar Dasar</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      
      {/* Floating Confetti (CSS-based simple overlay if active) */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center overflow-hidden">
          <motion.div 
            initial={{ scale: 0, opacity: 1 }}
            animate={{ scale: [1, 2, 3], opacity: [1, 1, 0] }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="w-32 h-32 bg-emerald-400 rounded-full blur-3xl absolute"
          />
        </div>
      )}
    </DashboardLayout>
  );
}
