import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { motion } from 'motion/react';
import { PenTool, Clock, Calendar, CheckCircle2, FileText, Upload } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';

export default function DetailTugasSiswa() {
  const { id } = useParams();

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/siswa/tugas" className="text-sm font-medium text-slate-500 hover:text-slate-900 bg-slate-100 px-4 py-2 rounded-xl transition-colors">
            Kembali
          </Link>
          <h2 className="text-2xl font-bold text-slate-900">Detail Tugas</h2>
        </div>

        <div className="glass p-8 rounded-3xl border border-white/40 shadow-sm space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-bl-[100px]"></div>
          
          <div className="flex justify-between items-start">
            <div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-50 text-amber-600 mb-4 border border-amber-100">
                <Clock className="w-4 h-4" />
                Belum Selesai
              </span>
              <h1 className="text-3xl font-display font-bold text-slate-900 mb-2">Makalah Sejarah Kemerdekaan</h1>
              <p className="text-slate-500 font-medium">Mata Pelajaran: Sejarah • Oleh: Budi Santoso</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-200 flex items-center justify-center text-slate-500">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tanggal Diberikan</p>
                <p className="font-semibold text-slate-700">12 Okt 2023</p>
              </div>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center text-red-500">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Batas Waktu</p>
                <p className="font-semibold text-red-600">15 Okt 2023, 23:59</p>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Instruksi Tugas</h3>
            <div className="prose prose-slate max-w-none text-slate-600">
              <p>Buatlah makalah tentang sejarah kemerdekaan Indonesia. Fokus pada peristiwa-peristiwa penting menjelang proklamasi.</p>
              <ul>
                <li>Minimal 5 halaman.</li>
                <li>Format PDF.</li>
                <li>Gunakan minimal 3 sumber referensi yang kredibel.</li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Materi Referensi</h3>
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between p-4 rounded-xl border border-slate-200 bg-white hover:border-blue-300 transition-colors cursor-pointer group">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-red-50 text-red-500 flex items-center justify-center">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-700 group-hover:text-blue-600 transition-colors">Bab 3 - Masa Persiapan Kemerdekaan.pdf</p>
                    <p className="text-xs text-slate-400">PDF • 2.4 MB</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <h3 className="font-bold text-lg text-slate-900 mb-4">Kumpulkan Tugas</h3>
            <div className="border-2 border-dashed border-slate-300 rounded-3xl p-10 flex flex-col items-center justify-center text-center bg-slate-50/50 hover:bg-slate-50 hover:border-blue-400 transition-all cursor-pointer">
              <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mb-4">
                <Upload className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-slate-700 mb-1">Pilih file atau tarik & lepas ke sini</h4>
              <p className="text-sm text-slate-500 mb-6">Format yang didukung: PDF, DOCX (Maks 10MB)</p>
              <button className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20">
                Pilih File
              </button>
            </div>
          </div>

        </div>
      </div>
    </DashboardLayout>
  );
}
