import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { motion } from 'motion/react';
import { User, Mail, Phone, MapPin, Book, Award, Calendar } from 'lucide-react';

export default function SiswaProfil() {
  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Profil Siswa</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:col-span-1 glass p-6 rounded-3xl border border-white/40 shadow-sm text-center"
          >
            <div className="w-32 h-32 mx-auto rounded-full bg-slate-200 mb-4 overflow-hidden border-4 border-white shadow-md">
              <img src="https://api.dicebear.com/7.x/notionists/svg?seed=Andi" alt="Andi Pratama" className="w-full h-full object-cover" />
            </div>
            <h3 className="font-bold text-xl text-slate-900">Andi Pratama</h3>
            <p className="text-slate-500 mb-2">Siswa Aktif</p>
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-700">
              Kelas X IPA 1
            </span>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="md:col-span-2 glass p-6 rounded-3xl border border-white/40 shadow-sm"
          >
            <h3 className="font-bold text-lg text-slate-900 mb-4 border-b border-slate-100 pb-2">Informasi Pribadi</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">NISN</p>
                <p className="font-medium text-slate-700">0081234567</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">NIS</p>
                <p className="font-medium text-slate-700">10293</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Email</p>
                <p className="font-medium text-slate-700">andi.pratama@siswa.sekolahverse.id</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Nomor HP</p>
                <p className="font-medium text-slate-700">0812-3456-7890</p>
              </div>
              <div className="sm:col-span-2">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Alamat</p>
                <p className="font-medium text-slate-700">Jl. Merdeka No. 45, Jakarta Selatan</p>
              </div>
            </div>

            <h3 className="font-bold text-lg text-slate-900 mb-4 mt-8 border-b border-slate-100 pb-2">Informasi Akademik</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Wali Kelas</p>
                <p className="font-medium text-slate-700">Bapak Hendra Gunawan</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Tahun Ajaran</p>
                <p className="font-medium text-slate-700">2023/2024</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Jurusan</p>
                <p className="font-medium text-slate-700">Ilmu Pengetahuan Alam (IPA)</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </DashboardLayout>
  );
}
