import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Calendar, Clock } from 'lucide-react';

export default function JadwalBelajar() {
  const schedule = [
    { day: 'Senin', subjects: [{ name: 'Matematika', time: '08:00 - 09:30', teacher: 'Budi Santoso' }, { name: 'Fisika', time: '10:00 - 11:30', teacher: 'Siti Aminah' }] },
    { day: 'Selasa', subjects: [{ name: 'Bahasa Indonesia', time: '08:00 - 09:30', teacher: 'Ratna Sari' }, { name: 'Biologi', time: '10:00 - 11:30', teacher: 'Hendra Gunawan' }] },
  ];
  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Jadwal Belajar</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {schedule.map(day => (
            <div key={day.day} className="glass p-6 rounded-3xl border border-white/40 shadow-sm">
              <h3 className="font-bold text-lg text-slate-900 mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-500" /> {day.day}
              </h3>
              <div className="space-y-4">
                {day.subjects.map(sub => (
                  <div key={sub.name} className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex justify-between items-center">
                    <div>
                      <p className="font-bold text-slate-800">{sub.name}</p>
                      <p className="text-sm text-slate-500">{sub.teacher}</p>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-medium text-blue-600 bg-blue-50 px-3 py-1 rounded-lg">
                      <Clock className="w-4 h-4" />
                      {sub.time}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
