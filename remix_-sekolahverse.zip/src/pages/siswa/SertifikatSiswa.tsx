import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Award, Download } from 'lucide-react';

export default function SertifikatSiswa() {
  const sertifikat = [
    { title: 'Mastering React.js', date: '12 Okt 2023', issuer: 'SekolahVerse' },
    { title: 'Dasar Pemrograman Python', date: '05 Sep 2023', issuer: 'SekolahVerse' },
  ];
  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Sertifikat Digital</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sertifikat.map((s, i) => (
            <div key={i} className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-amber-50 text-amber-500 rounded-2xl flex items-center justify-center">
                  <Award className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-slate-900">{s.title}</h3>
                  <p className="text-slate-500 text-sm">Diterbitkan: {s.date} oleh {s.issuer}</p>
                </div>
              </div>
              <button className="p-3 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-xl transition-colors">
                <Download className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
