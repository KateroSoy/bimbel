import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { PenTool, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function TugasSiswa() {
  const tugas = [
    { id: 1, title: 'Makalah Sejarah', subject: 'Sejarah', deadline: 'Besok, 23:59', status: 'Belum Selesai', color: 'text-amber-600 bg-amber-50' },
    { id: 2, title: 'Latihan Soal Aljabar', subject: 'Matematika', deadline: 'Lusa, 12:00', status: 'Selesai', color: 'text-emerald-600 bg-emerald-50' }
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Tugas & PR</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tugas.map((t, i) => (
            <Link key={i} to={`/siswa/tugas/${t.id}`} className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col hover:shadow-lg hover:-translate-y-1 hover:border-blue-300 transition-all cursor-pointer">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><PenTool className="w-6 h-6" /></div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${t.color}`}>{t.status}</span>
              </div>
              <h3 className="font-bold text-lg text-slate-900 mb-1">{t.title}</h3>
              <p className="text-slate-500 text-sm mb-4">{t.subject}</p>
              
              <div className="mt-auto flex items-center gap-2 text-sm font-medium text-slate-600 bg-slate-50 p-3 rounded-xl">
                <Clock className="w-4 h-4 text-slate-400" />
                Tenggat: {t.deadline}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
