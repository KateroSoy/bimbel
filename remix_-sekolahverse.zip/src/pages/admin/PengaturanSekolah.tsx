import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Save } from 'lucide-react';

export default function PengaturanSekolah() {
  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Pengaturan Sekolah</h2>
        <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Nama Sekolah</label>
              <input type="text" defaultValue="SMA Global Nusantara" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Alamat Sekolah</label>
              <textarea rows={3} defaultValue="Jl. Pendidikan No. 1, Jakarta" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors resize-none"></textarea>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Tahun Ajaran Aktif</label>
              <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors appearance-none">
                <option value="2023/2024">2023/2024</option>
                <option value="2024/2025">2024/2025</option>
              </select>
            </div>
            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-md flex items-center gap-2">
                <Save className="w-5 h-5" />
                Simpan Pengaturan
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
