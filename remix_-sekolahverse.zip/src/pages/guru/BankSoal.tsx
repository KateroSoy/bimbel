import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { motion } from 'motion/react';
import { FileText, Plus, Search, Filter, BookOpen, Clock, BarChart2 } from 'lucide-react';

export default function BankSoal() {
  const soalPacks = [
    { title: 'Persiapan UTS Matematika Wajib', subject: 'Matematika', grade: 'X', questions: 40, time: '90 Menit', difficulty: 'Sedang' },
    { title: 'Latihan Tenses & Grammar', subject: 'Bahasa Inggris', grade: 'XI', questions: 50, time: '60 Menit', difficulty: 'Sulit' },
    { title: 'Kuis Biologi: Sel', subject: 'IPA', grade: 'XII', questions: 25, time: '45 Menit', difficulty: 'Mudah' },
    { title: 'Tryout USBN Sejarah', subject: 'IPS', grade: 'XII', questions: 100, time: '120 Menit', difficulty: 'Sedang' },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-display font-bold text-slate-900 mb-2">Bank Soal</h2>
            <p className="text-slate-500">Kelola dan buat paket soal ujian untuk siswa Anda.</p>
          </div>
          <button className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-md shadow-blue-600/20">
            <Plus className="w-5 h-5" />
            Buat Paket Soal Baru
          </button>
        </div>

        {/* Filters */}
        <div className="glass p-4 rounded-2xl border border-white/40 flex flex-col md:flex-row gap-4 shadow-sm">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari judul soal atau mata pelajaran..." 
              className="w-full pl-12 pr-4 py-3 bg-white/60 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium placeholder:font-normal shadow-sm"
            />
          </div>
          <div className="flex gap-2">
            <select className="px-4 py-3 bg-white/60 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-700 font-medium shadow-sm">
              <option value="">Semua Mata Pelajaran</option>
              <option value="matematika">Matematika</option>
              <option value="bahasa">Bahasa</option>
              <option value="ipa">IPA</option>
              <option value="ips">IPS</option>
            </select>
            <select className="px-4 py-3 bg-white/60 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-700 font-medium shadow-sm">
              <option value="">Semua Kelas</option>
              <option value="10">Kelas X</option>
              <option value="11">Kelas XI</option>
              <option value="12">Kelas XII</option>
            </select>
            <button className="flex items-center justify-center w-12 h-12 bg-white/60 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-700 font-medium shadow-sm">
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Categories/Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Total Paket Soal', value: '142', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'Total Butir Soal', value: '3,840', icon: BookOpen, color: 'text-emerald-600', bg: 'bg-emerald-50' },
            { label: 'Rata-rata Waktu', value: '60 Min', icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
            { label: 'Tingkat Kesulitan', value: 'Sedang', icon: BarChart2, color: 'text-amber-600', bg: 'bg-amber-50' }
          ].map((stat, i) => (
             <motion.div 
               key={stat.label}
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: i * 0.1 }}
               className="glass p-5 rounded-3xl border border-white/40 shadow-sm flex flex-col items-center text-center hover:-translate-y-1 hover:shadow-md transition-all group"
             >
               <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 ${stat.bg} ${stat.color} group-hover:scale-110 transition-transform`}>
                 <stat.icon className="w-6 h-6" />
               </div>
               <p className="font-display font-bold text-2xl text-slate-900 leading-tight">{stat.value}</p>
               <p className="text-slate-500 text-xs font-medium uppercase tracking-wide mt-1">{stat.label}</p>
             </motion.div>
          ))}
        </div>

        <h3 className="font-display font-bold text-xl text-slate-900 mt-8 mb-4">Paket Soal Terbaru</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {soalPacks.map((pack, index) => (
            <motion.div
              key={pack.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + (index * 0.1) }}
              className="glass p-6 rounded-3xl border border-white/40 hover:shadow-lg hover:border-blue-200 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-600 group-hover:bg-blue-600 group-hover:text-white transition-colors shrink-0 shadow-inner">
                  <FileText className="w-6 h-6" />
                </div>
                <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold tracking-wide uppercase bg-slate-100 text-slate-600">
                  Kelas {pack.grade}
                </span>
              </div>
              
              <h3 className="font-bold text-slate-900 text-lg mb-1 leading-tight group-hover:text-blue-600 transition-colors">{pack.title}</h3>
              <p className="text-sm font-medium text-slate-500 mb-6">{pack.subject}</p>
              
              <div className="grid grid-cols-3 gap-2 border-t border-slate-100 pt-4">
                <div>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold mb-1">Soal</p>
                  <p className="font-bold text-slate-700 text-sm">{pack.questions} Butir</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold mb-1">Durasi</p>
                  <p className="font-bold text-slate-700 text-sm">{pack.time}</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold mb-1">Kesulitan</p>
                  <p className={`font-bold text-sm ${pack.difficulty === 'Sulit' ? 'text-rose-600' : pack.difficulty === 'Sedang' ? 'text-amber-600' : 'text-emerald-600'}`}>
                    {pack.difficulty}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
