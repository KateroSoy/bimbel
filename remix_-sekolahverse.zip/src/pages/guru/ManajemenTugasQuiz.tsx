import { useState, useEffect } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Calendar, Clock, FileText, Users, Search, MoreVertical, PenTool, CheckCircle2, X } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';

const mockTugas = [
  { id: 1, title: 'Makalah Sejarah Kemerdekaan', kelas: 'X IPA 1', deadline: '2023-11-15T23:59', submitted: 28, total: 32, status: 'Aktif' },
  { id: 2, title: 'Laporan Praktikum Biologi', kelas: 'X IPA 2', deadline: '2023-11-18T12:00', submitted: 15, total: 30, status: 'Aktif' },
  { id: 3, title: 'Tugas Bahasa Indonesia - Cerpen', kelas: 'X IPS 1', deadline: '2023-10-10T23:59', submitted: 28, total: 28, status: 'Selesai' },
];

const mockQuiz = [
  { id: 1, title: 'Ulangan Harian Matematika', kelas: 'X IPA 1', deadline: '2023-11-20T10:00', submitted: 32, total: 32, status: 'Selesai' },
  { id: 2, title: 'Quiz Bahasa Inggris - Tenses', kelas: 'X IPS 1', deadline: '2023-11-22T08:00', submitted: 5, total: 28, status: 'Aktif' },
];

export default function ManajemenTugasQuiz() {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'tugas' | 'quiz'>(
    location.pathname.includes('quiz') ? 'quiz' : 'tugas'
  );
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    setActiveTab(location.pathname.includes('quiz') ? 'quiz' : 'tugas');
  }, [location.pathname]);

  const currentData = activeTab === 'tugas' ? mockTugas : mockQuiz;

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header & Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-display font-bold text-slate-900 mb-2">
              Manajemen {activeTab === 'tugas' ? 'Tugas' : 'Quiz'}
            </h2>
            <p className="text-slate-500">
              Kelola penugasan, evaluasi, dan pantau progress pengerjaan siswa.
            </p>
          </div>
          
          <button 
            onClick={() => setShowModal(true)}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl font-bold shadow-md hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Buat {activeTab === 'tugas' ? 'Tugas' : 'Quiz'} Baru
          </button>
        </div>

        {/* Tabs & Search */}
        <div className="glass p-4 rounded-2xl border border-white/40 flex flex-col md:flex-row gap-4 shadow-sm justify-between items-center">
          <div className="flex gap-2 bg-slate-100 p-1 rounded-xl w-full md:w-auto">
            <button
              onClick={() => setActiveTab('tugas')}
              className={`flex-1 md:flex-none px-6 py-2.5 rounded-lg font-bold text-sm transition-all ${
                activeTab === 'tugas' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
              }`}
            >
              Penugasan
            </button>
            <button
              onClick={() => setActiveTab('quiz')}
              className={`flex-1 md:flex-none px-6 py-2.5 rounded-lg font-bold text-sm transition-all ${
                activeTab === 'quiz' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
              }`}
            >
              Quiz / Ujian
            </button>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder={`Cari ${activeTab}...`}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium shadow-sm"
            />
          </div>
        </div>

        {/* Data Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {currentData.map((item, index) => (
              <motion.div
                key={`${activeTab}-${item.id}`}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2, delay: index * 0.05 }}
                className="glass rounded-3xl border border-white/40 overflow-hidden hover:shadow-xl transition-all group flex flex-col bg-white"
              >
                <div className="p-6 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div className={`p-3 rounded-2xl ${
                      activeTab === 'tugas' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'
                    }`}>
                      {activeTab === 'tugas' ? <PenTool className="w-6 h-6" /> : <FileText className="w-6 h-6" />}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      item.status === 'Aktif' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 text-lg leading-tight mb-2 group-hover:text-blue-600 transition-colors">
                    {item.title}
                  </h3>
                  
                  <div className="flex items-center gap-2 text-sm text-slate-500 font-medium mb-6">
                    <Users className="w-4 h-4" />
                    {item.kelas}
                  </div>

                  <div className="mt-auto space-y-4">
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                        <Clock className="w-4 h-4" />
                        Tenggat Waktu
                      </div>
                      <p className="text-sm font-medium text-slate-700">
                        {new Date(item.deadline).toLocaleDateString('id-ID', {
                          weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
                        })}
                      </p>
                    </div>

                    <div>
                      <div className="flex justify-between items-end mb-2">
                        <span className="text-xs font-bold text-slate-500">Progress Pengumpulan</span>
                        <span className="text-sm font-bold text-slate-900">{item.submitted}/{item.total}</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div 
                          className={`h-2 rounded-full transition-all duration-1000 ${
                            item.submitted === item.total ? 'bg-emerald-500' : 'bg-blue-500'
                          }`}
                          style={{ width: `${(item.submitted / item.total) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex gap-2">
                  <Link to={`/guru/tugas/${item.id}`} className="flex-1 py-2.5 flex items-center justify-center bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors">
                    Lihat Detail
                  </Link>
                  <button className="w-11 flex items-center justify-center bg-white border border-slate-200 text-slate-400 rounded-xl hover:text-slate-700 hover:bg-slate-50 transition-colors">
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

      </div>

      {/* Modal Buat Baru */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 className="text-xl font-bold text-slate-900">
                  Buat {activeTab === 'tugas' ? 'Tugas' : 'Quiz'} Baru
                </h3>
                <button 
                  onClick={() => setShowModal(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-slate-200 text-slate-500 hover:bg-slate-300 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-6 overflow-y-auto flex-1 space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Judul {activeTab === 'tugas' ? 'Tugas' : 'Quiz'}</label>
                  <input 
                    type="text" 
                    placeholder="Contoh: Ulangan Harian Bab 1"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Deskripsi / Instruksi</label>
                  <textarea 
                    rows={4}
                    placeholder="Tuliskan instruksi pengerjaan..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors resize-none"
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Kelas Tujuan</label>
                    <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors appearance-none">
                      <option value="">Pilih Kelas...</option>
                      <option value="X IPA 1">X IPA 1</option>
                      <option value="X IPA 2">X IPA 2</option>
                      <option value="X IPS 1">X IPS 1</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Tenggat Waktu</label>
                    <input 
                      type="datetime-local" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                {activeTab === 'quiz' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Durasi (Menit)</label>
                      <input 
                        type="number" 
                        placeholder="Contoh: 60"
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Sumber Soal</label>
                      <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors appearance-none">
                        <option value="bank">Ambil dari Bank Soal</option>
                        <option value="new">Buat Soal Baru</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end gap-3">
                <button 
                  onClick={() => setShowModal(false)}
                  className="px-6 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                >
                  Batal
                </button>
                <button 
                  onClick={() => setShowModal(false)}
                  className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-md flex items-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  Simpan & Terbitkan
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </DashboardLayout>
  );
}
