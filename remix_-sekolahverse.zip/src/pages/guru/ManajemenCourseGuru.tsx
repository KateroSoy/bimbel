import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { BookOpen, Edit } from 'lucide-react';

export default function ManajemenCourseGuru() {
  const courses = [
    { title: 'Matematika Dasar', status: 'Draft', lessons: 5 },
    { title: 'Fisika Kuantum', status: 'Published', lessons: 12 }
  ];
  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-900">Manajemen Course & Materi</h2>
          <button className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-blue-500/30 transition-all active:scale-95">
            + Tambah Course
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((c, i) => (
            <div key={i} className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl w-fit mb-4">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-slate-900 mb-1">{c.title}</h3>
              <p className="text-slate-500 text-sm mb-4">{c.lessons} Materi / Bab</p>
              <div className="mt-auto flex justify-between items-center pt-4 border-t border-slate-100">
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${c.status === 'Published' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-600'}`}>
                  {c.status}
                </span>
                <button className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
                  <Edit className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
