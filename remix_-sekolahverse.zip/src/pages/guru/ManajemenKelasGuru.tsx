import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UsersRound, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ManajemenKelasGuru() {
  const classes = [
    { name: 'X IPA 1', students: 32, schedule: 'Senin, Rabu' },
    { name: 'X IPA 2', students: 30, schedule: 'Selasa, Kamis' }
  ];
  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Manajemen Kelas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {classes.map((c, i) => (
            <div key={i} className="glass p-6 rounded-3xl border border-white/40 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                    <UsersRound className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-xl text-slate-900">{c.name}</h3>
                </div>
                <button className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
                  <Settings className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-2 text-sm text-slate-600">
                <p><strong>Jumlah Siswa:</strong> {c.students} Orang</p>
                <p><strong>Jadwal Mengajar:</strong> {c.schedule}</p>
              </div>
              <Link to="/guru/kelas/1" className="w-full mt-4 flex items-center justify-center py-2 bg-slate-50 text-slate-700 font-bold rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors">
                Lihat Detail Kelas
              </Link>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
