import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { ChevronLeft, CheckCircle2, Clock, Users, Search, Download } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';

export default function DetailTugasGuru() {
  const { id } = useParams();

  const submissions = [
    { id: 1, name: 'Andi Pratama', status: 'Dinilai', score: 85, submittedAt: '2023-11-14 10:30' },
    { id: 2, name: 'Budi Santoso', status: 'Perlu Dinilai', score: null, submittedAt: '2023-11-15 09:15' },
    { id: 3, name: 'Siti Aminah', status: 'Belum Mengumpulkan', score: null, submittedAt: null },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/guru/tugas" className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
            <ChevronLeft className="w-6 h-6 text-slate-600" />
          </Link>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Makalah Sejarah Kemerdekaan</h2>
            <p className="text-slate-500 text-sm">Kelas X IPA 1</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-3 text-slate-600 mb-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span className="font-bold">Terkumpul</span>
            </div>
            <p className="text-3xl font-bold text-slate-900">28 <span className="text-sm text-slate-500 font-medium">/ 32</span></p>
          </div>
          
          <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-3 text-slate-600 mb-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span className="font-bold">Sudah Dinilai</span>
            </div>
            <p className="text-3xl font-bold text-slate-900">25</p>
          </div>

          <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-3 text-slate-600 mb-2">
              <Clock className="w-5 h-5 text-amber-600" />
              <span className="font-bold">Tenggat Waktu</span>
            </div>
            <p className="text-lg font-bold text-slate-900">15 Nov 2023</p>
          </div>
        </div>

        <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h3 className="font-bold text-lg text-slate-900">Daftar Pengumpulan</h3>
            
            <div className="flex gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari nama siswa..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium"
                />
              </div>
              <button className="p-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-colors">
                <Download className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[700px]">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50">
                  <th className="p-4 font-bold text-slate-700">Nama Siswa</th>
                  <th className="p-4 font-bold text-slate-700">Waktu Kumpul</th>
                  <th className="p-4 font-bold text-slate-700">Status</th>
                  <th className="p-4 font-bold text-slate-700">Nilai</th>
                  <th className="p-4 font-bold text-slate-700 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {submissions.map((s) => (
                  <tr key={s.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="p-4 font-medium text-slate-900">{s.name}</td>
                    <td className="p-4 text-slate-600 text-sm">{s.submittedAt || '-'}</td>
                    <td className="p-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        s.status === 'Dinilai' ? 'bg-emerald-50 text-emerald-600' :
                        s.status === 'Perlu Dinilai' ? 'bg-amber-50 text-amber-600' :
                        'bg-red-50 text-red-600'
                      }`}>
                        {s.status}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-slate-900">{s.score !== null ? s.score : '-'}</td>
                    <td className="p-4 text-right">
                      {s.status !== 'Belum Mengumpulkan' && (
                        <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg font-bold hover:bg-blue-100 transition-colors text-sm">
                          Beri Nilai
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
