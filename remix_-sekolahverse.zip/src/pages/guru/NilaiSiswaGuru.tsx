import { DashboardLayout } from '../../components/layout/DashboardLayout';

export default function NilaiSiswaGuru() {
  const students = [
    { name: 'Andi Pratama', class: 'X IPA 1', score: 85 },
    { name: 'Budi Santoso', class: 'X IPA 1', score: 92 },
    { name: 'Siti Aminah', class: 'X IPA 2', score: 78 },
  ];
  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Nilai Siswa</h2>
        <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="p-4 font-bold text-slate-700">Nama Siswa</th>
                <th className="p-4 font-bold text-slate-700">Kelas</th>
                <th className="p-4 font-bold text-slate-700">Nilai Akhir</th>
              </tr>
            </thead>
            <tbody>
              {students.map((s, i) => (
                <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                  <td className="p-4 font-medium text-slate-900">{s.name}</td>
                  <td className="p-4 text-slate-600">{s.class}</td>
                  <td className="p-4 font-bold text-blue-600">{s.score}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
