import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UsersRound, FileText, ChevronLeft, Calendar, ArrowRight, UserCircle2 } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';

export default function DetailKelasGuru() {
  const { id } = useParams();

  const students = [
    { id: 1, name: 'Andi Pratama', nis: '1001', attendance: '98%', avgScore: 85 },
    { id: 2, name: 'Budi Santoso', nis: '1002', attendance: '95%', avgScore: 92 },
    { id: 3, name: 'Siti Aminah', nis: '1003', attendance: '100%', avgScore: 78 },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/guru/kelas" className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
            <ChevronLeft className="w-6 h-6 text-slate-600" />
          </Link>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Detail Kelas X IPA 1</h2>
            <p className="text-slate-500 text-sm">Tahun Ajaran 2023/2024</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-3 text-slate-600 mb-2">
              <UsersRound className="w-5 h-5 text-blue-600" />
              <span className="font-bold">Total Siswa</span>
            </div>
            <p className="text-3xl font-bold text-slate-900">32</p>
          </div>
          
          <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-3 text-slate-600 mb-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              <span className="font-bold">Rata-rata Kehadiran</span>
            </div>
            <p className="text-3xl font-bold text-slate-900">96.5%</p>
          </div>

          <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col gap-2">
            <div className="flex items-center gap-3 text-slate-600 mb-2">
              <FileText className="w-5 h-5 text-amber-600" />
              <span className="font-bold">Rata-rata Nilai</span>
            </div>
            <p className="text-3xl font-bold text-slate-900">83.2</p>
          </div>
        </div>

        <div className="glass p-6 rounded-3xl border border-white/40 shadow-sm">
          <h3 className="font-bold text-lg text-slate-900 mb-6">Daftar Siswa</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="p-4 font-bold text-slate-700">Nama Siswa</th>
                  <th className="p-4 font-bold text-slate-700">NIS</th>
                  <th className="p-4 font-bold text-slate-700">Kehadiran</th>
                  <th className="p-4 font-bold text-slate-700">Rata-rata Nilai</th>
                  <th className="p-4 font-bold text-slate-700 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <UserCircle2 className="w-8 h-8 text-slate-400" />
                        <span className="font-medium text-slate-900">{s.name}</span>
                      </div>
                    </td>
                    <td className="p-4 text-slate-600">{s.nis}</td>
                    <td className="p-4 text-slate-600">{s.attendance}</td>
                    <td className="p-4 text-blue-600 font-bold">{s.avgScore}</td>
                    <td className="p-4 text-right">
                      <Link to={`/guru/progress-siswa`} className="inline-flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors font-medium text-sm">
                        Lihat Progress <ArrowRight className="w-4 h-4" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
